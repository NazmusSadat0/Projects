import { useMemo } from "react";
import { Shape } from "three";

import { Box, Cylinder } from "./Primitives";

function Headphones() {
  return (
    <group
      position={[-1.42, 1.51, -1.66]}
      rotation={[-Math.PI / 2, 0, -0.2]}
      scale={0.72}
    >
      {/* Padded headband */}
      <mesh castShadow>
        <torusGeometry
          args={[0.24, 0.035, 12, 40, Math.PI]}
        />
        <meshStandardMaterial
          color="#3d443c"
          roughness={0.78}
        />
      </mesh>

      {[-1, 1].map((side) => (
        <group key={side} position={[side * 0.24, 0, 0]}>
          <Box
            size={[0.11, 0.2, 0.14]}
            color="#444b43"
            radius={0.045}
          />

          <Box
            size={[0.055, 0.17, 0.12]}
            position={[-side * 0.05, 0, 0]}
            color="#747c6d"
            radius={0.025}
          />
        </group>
      ))}
    </group>
  );
}

function WindowLandscape() {
  const distantHills = useMemo(() => {
    const shape = new Shape();

    shape.moveTo(-1.86, -0.65);
    shape.lineTo(-1.86, -0.25);
    shape.lineTo(-1.32, 0.05);
    shape.lineTo(-0.9, -0.16);
    shape.lineTo(-0.35, 0.22);
    shape.lineTo(0.22, -0.12);
    shape.lineTo(0.78, 0.14);
    shape.lineTo(1.35, -0.2);
    shape.lineTo(1.86, -0.02);
    shape.lineTo(1.86, -0.65);
    shape.closePath();

    return shape;
  }, []);

  const nearHills = useMemo(() => {
    const shape = new Shape();

    shape.moveTo(-1.86, -0.65);
    shape.lineTo(-1.86, -0.4);

    shape.bezierCurveTo(
      -0.9,
      0.05,
      -0.5,
      -0.58,
      0.2,
      -0.3
    );

    shape.bezierCurveTo(
      0.9,
      -0.02,
      1.3,
      -0.45,
      1.86,
      -0.28
    );

    shape.lineTo(1.86, -0.65);
    shape.closePath();

    return shape;
  }, []);

  return (
    <group position={[-0.3, 2.4, -2.91]}>
      <mesh position={[1.1, 0.33, 0.001]}>
        <circleGeometry args={[0.16, 40]} />
        <meshBasicMaterial color="#f7e7bb" />
      </mesh>

      <mesh position={[0, 0, 0.003]}>
        <shapeGeometry args={[distantHills]} />
        <meshBasicMaterial color="#a0b6aa" />
      </mesh>

      <mesh position={[0, 0, 0.006]}>
        <shapeGeometry args={[nearHills]} />
        <meshBasicMaterial color="#80998b" />
      </mesh>
    </group>
  );
}

function RugDetails() {
  return (
    <group>
      {/* Woven border */}
      {[-1, 1].map((side) => (
        <group key={side}>
          <Box
            size={[3.29, 0.005, 0.026]}
            position={[-0.65, 0.054, -0.15 + side * 1.025]}
            color="#bba987"
            radius={0.002}
          />

          <Box
            size={[0.026, 0.005, 2.07]}
            position={[-0.65 + side * 1.63, 0.054, -0.15]}
            color="#bba987"
            radius={0.002}
          />
        </group>
      ))}

      {/* Short fringes */}
      {Array.from({ length: 34 }, (_, i) =>
        [-1, 1].map((side) => (
          <Box
            key={`${i}-${side}`}
            size={[0.025, 0.009, 0.13]}
            position={[
              -2.28 + i * 0.099,
              0.035,
              -0.15 + side * 1.17,
            ]}
            color="#d2be9b"
            radius={0.004}
          />
        ))
      )}
    </group>
  );
}

function DeskDetails() {
  return (
    <group>
      <Headphones />

      {/* Pen cup */}
      <Cylinder
        radius={0.095}
        height={0.2}
        position={[1.58, 1.54, -2.45]}
        color="#bca481"
      />

      {[0, 1, 2].map((i) => (
        <Cylinder
          key={i}
          radius={0.009}
          height={0.34}
          position={[
            1.54 + i * 0.04,
            1.68,
            -2.45,
          ]}
          rotation={[0, 0, (i - 1) * 0.12]}
          color={["#444d42", "#c57943", "#6c7e75"][i]}
        />
      ))}

      {/* Small desktop notebook */}
      <group
        position={[-1.73, 1.468, -2.5]}
        rotation={[0, 0.12, 0]}
      >
        <Box
          size={[0.43, 0.055, 0.3]}
          color="#d4c4a5"
          radius={0.012}
        />

        <Box
          size={[0.39, 0.025, 0.28]}
          position={[0.009, 0.008, 0]}
          color="#eee4ce"
          radius={0.004}
        />
      </group>

      {/* Keyboard spacebar */}
      <Box
        size={[0.41, 0.015, 0.055]}
        position={[-0.25, 1.508, -1.37]}
        color="#d5cebd"
        radius={0.007}
      />

      {/* Monitor power indicator */}
      <mesh position={[0.54, 1.78, -2.163]}>
        <sphereGeometry args={[0.008, 12, 8]} />
        <meshBasicMaterial color="#94d5bf" />
      </mesh>
    </group>
  );
}

export default function RoomDetails() {
  return (
    <group>
      <WindowLandscape />
      <RugDetails />
      <DeskDetails />
    </group>
  );
}
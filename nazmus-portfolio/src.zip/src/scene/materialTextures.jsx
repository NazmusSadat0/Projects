import {
  CanvasTexture,
  RepeatWrapping,
  SRGBColorSpace,
} from "three";

const textureCache = new Map();

function createRandom(seed) {
  let value = seed;

  return () => {
    value = (value * 1664525 + 1013904223) >>> 0;
    return value / 4294967296;
  };
}

function makeTexture(type) {
  const canvas = document.createElement("canvas");

  canvas.width = 512;
  canvas.height = 512;

  const context = canvas.getContext("2d");
  const random = createRandom(type === "wood" ? 23 : 91);

  context.fillStyle = "#eee8dc";
  context.fillRect(0, 0, 512, 512);

  if (type === "wood") {
    // Long, irregular grain running across each surface.
    for (let i = 0; i < 440; i++) {
      const baseY = random() * 512;
      const amplitude = 1 + random() * 5;
      const phase = random() * Math.PI * 2;

      context.strokeStyle = `rgba(77, 49, 24, ${
        0.025 + random() * 0.1
      })`;

      context.lineWidth = 0.3 + random() * 1.3;
      context.beginPath();

      for (let x = 0; x <= 512; x += 8) {
        const y =
          baseY +
          Math.sin(x * 0.014 + phase) * amplitude +
          Math.sin(x * 0.043 + phase) * 0.7;

        if (x === 0) {
          context.moveTo(x, y);
        } else {
          context.lineTo(x, y);
        }
      }

      context.stroke();
    }

    // A few subtle knots.
    for (let i = 0; i < 3; i++) {
      const x = 70 + random() * 370;
      const y = 70 + random() * 370;

      for (let ring = 0; ring < 9; ring++) {
        context.beginPath();

        context.ellipse(
          x,
          y,
          8 + ring * 4,
          1.5 + ring * 1.2,
          0,
          0,
          Math.PI * 2
        );

        context.strokeStyle = "rgba(90, 58, 30, 0.035)";
        context.lineWidth = 0.8;
        context.stroke();
      }
    }
  } else {
    // Fine woven threads.
    for (let i = 0; i < 512; i += 4) {
      context.strokeStyle =
        i % 8 === 0
          ? "rgba(255,255,255,0.35)"
          : "rgba(80,65,45,0.12)";

      context.lineWidth = 1;

      context.beginPath();
      context.moveTo(i, 0);
      context.lineTo(i, 512);
      context.stroke();

      context.beginPath();
      context.moveTo(0, i);
      context.lineTo(512, i);
      context.stroke();
    }
  }

  // Fine surface variation.
  const image = context.getImageData(0, 0, 512, 512);

  for (let i = 0; i < image.data.length; i += 4) {
    const noise = (random() - 0.5) * 12;

    image.data[i] += noise;
    image.data[i + 1] += noise;
    image.data[i + 2] += noise;
  }

  context.putImageData(image, 0, 0);

  const color = new CanvasTexture(canvas);

  color.colorSpace = SRGBColorSpace;
  color.wrapS = RepeatWrapping;
  color.wrapT = RepeatWrapping;
  color.anisotropy = 4;

  // Bump data uses the same drawing without color-space conversion.
  const bump = new CanvasTexture(canvas);

  bump.wrapS = RepeatWrapping;
  bump.wrapT = RepeatWrapping;
  bump.anisotropy = 4;

  return { color, bump };
}

export function getMaterialTextures(type) {
  if (!textureCache.has(type)) {
    textureCache.set(type, makeTexture(type));
  }

  return textureCache.get(type);
}
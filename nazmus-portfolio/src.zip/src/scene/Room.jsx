import { Box, Cylinder, Sphere, Plant } from "./Primitives";

import {
  DetailedDeskChair,
  DetailedLounge,
  DetailedLamp,
  DetailedBookshelf,
} from "./DetailedFurniture";

const wood = "#aa754d";
const darkWood = "#785136";

function Shelf() {
  return <DetailedBookshelf />;
}

function Computer() {
  return (
    <group position={[-0.25, 1.44, -2.22]}>
      {/* Monitor base */}
      <Box
        size={[0.58, 0.045, 0.37]}
        position={[0, 0.035, 0.06]}
        color="#343632"
      />

      <Box
        size={[0.12, 0.37, 0.12]}
        position={[0, 0.21, 0]}
        color="#343632"
      />

      {/* Monitor body */}
      <Box
        size={[1.85, 1.03, 0.1]}
        position={[0, 0.79, 0]}
        color="#252b2b"
        radius={0.04}
      />

      {/* Screen */}
      <mesh position={[0, 0.79, 0.056]}>
        <planeGeometry args={[1.73, 0.91]} />
        <meshBasicMaterial color="#18292d" />
      </mesh>

      {/* Decorative code lines */}
      {Array.from({ length: 11 }, (_, i) => (
        <mesh
          key={i}
          position={[
            -0.54 + (i % 3) * 0.07,
            1.12 - i * 0.064,
            0.06,
          ]}
        >
          <planeGeometry args={[0.34 + (i % 4) * 0.15, 0.018]} />
          <meshBasicMaterial
            color={["#d79367", "#9abdb2", "#ddc997"][i % 3]}
          />
        </mesh>
      ))}

      {/* Keyboard */}
      <Box
        size={[1.13, 0.055, 0.39]}
        position={[0, 0.032, 0.67]}
        color="#e5dfcf"
      />

      {Array.from({ length: 36 }, (_, i) => (
        <Box
          key={i}
          size={[0.07, 0.013, 0.065]}
          position={[
            -0.49 + (i % 12) * 0.089,
            0.066,
            0.55 + Math.floor(i / 12) * 0.1,
          ]}
          color="#bfb9aa"
          radius={0.006}
        />
      ))}

      {/* Mouse */}
      <Sphere
        position={[0.89, 0.055, 0.64]}
        scale={[0.1, 0.05, 0.16]}
        color="#eee9dc"
      />
    </group>
  );
}

function Robot() {
  return (
    <group position={[1.15, 1.45, -2.2]}>
      <Sphere
        position={[0, 0.19, 0]}
        scale={[0.16, 0.2, 0.12]}
      />

      <Box
        position={[0, 0.43, 0]}
        size={[0.36, 0.29, 0.25]}
        radius={0.09}
        color="#eee9db"
      />

      <Box
        position={[0, 0.43, 0.127]}
        size={[0.27, 0.17, 0.025]}
        radius={0.04}
        color="#243a40"
      />

      {[-1, 1].map((side) => (
        <group key={side}>
          {/* Eye */}
          <Sphere
            position={[side * 0.07, 0.44, 0.145]}
            scale={[0.027, 0.04, 0.014]}
            color="#8de3e6"
          />

          {/* Foot */}
          <Sphere
            position={[side * 0.11, 0.038, 0.065]}
            scale={[0.085, 0.045, 0.12]}
          />

          {/* Arm */}
          <Sphere
            position={[side * 0.2, 0.22, 0]}
            scale={[0.058, 0.12, 0.055]}
          />
        </group>
      ))}
    </group>
  );
}

function Desk() {
  return (
    <group>
      {/* Main wooden desktop */}
      <Box
        size={[5.15, 0.14, 1.3]}
        position={[0.05, 1.37, -2.02]}
        color={wood}
        radius={0.045}
      />

      {/* Darker underside edge */}
      <Box
        size={[5.05, 0.035, 1.22]}
        position={[0.05, 1.292, -2.02]}
        color={darkWood}
        radius={0.012}
      />

      {/* Left support */}
      <Box
        size={[0.15, 1.3, 1.15]}
        position={[-2.43, 0.65, -2.02]}
        color={darkWood}
        radius={0.02}
      />

      {/* Back modesty panel */}
      <Box
        size={[3.95, 0.35, 0.07]}
        position={[-0.37, 1.04, -2.57]}
        color={darkWood}
        radius={0.008}
      />

      {/* Drawer cabinet body */}
      <Box
        size={[1.02, 1.25, 1.15]}
        position={[2.05, 0.63, -2.02]}
        color="#747765"
        radius={0.015}
      />

      {/* Recessed cabinet foot */}
      <Box
        size={[0.9, 0.075, 1.01]}
        position={[2.05, 0.045, -2.04]}
        color="#555c4c"
        radius={0.01}
      />

      {/* Individual drawer fronts and pulls */}
      {[0.23, 0.64, 1.05].map((height) => (
        <group key={height}>
          <Box
            size={[0.94, 0.374, 0.045]}
            position={[2.05, height, -1.419]}
            color="#878975"
            radius={0.013}
          />

          {/* Handle mounting points */}
          {[-1, 1].map((side) => (
            <Box
              key={side}
              size={[0.022, 0.025, 0.043]}
              position={[
                2.05 + side * 0.145,
                height + 0.08,
                -1.378,
              ]}
              color="#4d5146"
              radius={0.005}
            />
          ))}

          <Box
            size={[0.32, 0.025, 0.022]}
            position={[2.05, height + 0.08, -1.355]}
            color="#4d5146"
            radius={0.008}
          />
        </group>
      ))}

      {/* Desk mat beneath keyboard and mouse */}
      <Box
        size={[2.15, 0.008, 0.56]}
        position={[0.02, 1.448, -1.55]}
        color="#697262"
        surface="fabric"
        radius={0.002}
      />

      <Computer />
      <Robot />

      {/* Improved phone stand */}
      <group position={[2, 1.45, -2.04]}>
        <Box
          size={[0.33, 0.035, 0.3]}
          position={[0, 0.018, 0]}
          color={darkWood}
          radius={0.012}
        />

        <Box
          size={[0.2, 0.21, 0.035]}
          position={[0, 0.13, -0.045]}
          rotation={[-0.2, 0, 0]}
          color={wood}
          radius={0.008}
        />

        <group
          position={[0, 0.285, 0.008]}
          rotation={[-0.14, -0.12, 0]}
        >
          {/* Phone body */}
          <Box
            size={[0.25, 0.48, 0.035]}
            color="#252c2e"
            radius={0.011}
          />

          {/* Screen */}
          <Box
            size={[0.221, 0.443, 0.006]}
            position={[0, 0, 0.021]}
            color="#a9c4c5"
            radius={0.002}
          />

          {/* Camera/speaker island */}
          <Box
            size={[0.074, 0.015, 0.005]}
            position={[0, 0.197, 0.026]}
            color="#252c2e"
            radius={0.002}
          />

          {/* Home indicator */}
          <Box
            size={[0.069, 0.005, 0.004]}
            position={[0, -0.202, 0.026]}
            color="#edf0de"
            radius={0.001}
          />
        </group>
      </group>

      <DetailedLamp />

      <Plant
        position={[-1.25, 1.45, -2.35]}
        scale={0.4}
      />
    </group>
  );
}

function Chair() {
  return <DetailedDeskChair />;
}

function Shelf() {
  return (
    <group position={[-3.5, 0, -0.72]}>
      {/* Horizontal shelves */}
      {[0.15, 0.75, 1.4].map((height) => (
        <Box
          key={height}
          size={[0.78, 0.09, 3.6]}
          position={[0, height, 0]}
          color={wood}
        />
      ))}

      {/* Vertical dividers */}
      {[-1.75, -0.55, 0.6, 1.75].map((depth) => (
        <Box
          key={depth}
          size={[0.75, 1.3, 0.07]}
          position={[0, 0.76, depth]}
          color={wood}
        />
      ))}

      {/* Upper books */}
      {Array.from({ length: 16 }, (_, i) => {
        const bookHeight = 0.34 + (i % 3) * 0.06;

        return (
          <Box
            key={i}
            size={[0.51, bookHeight, 0.09]}
            position={[
              0.035,
              0.8 + bookHeight / 2,
              -1.6 + i * 0.14,
            ]}
            color={["#d3c5a5", "#718375", "#b97c51", "#e5d7be"][i % 4]}
          />
        );
      })}

      {/* Lower books */}
      {Array.from({ length: 6 }, (_, i) => (
        <Box
          key={i}
          size={[0.54, 0.39, 0.13]}
          position={[0.035, 0.39, 0.72 + i * 0.14]}
          color={i % 2 ? "#778978" : "#d0ae80"}
        />
      ))}

      <Plant
        position={[0, 1.45, -1.22]}
        scale={0.6}
      />

      <Sphere
        position={[0, 1.62, 0.6]}
        scale={[0.16, 0.18, 0.16]}
        color="#dcc8a3"
      />
    </group>
  );
}

function Lounge() {
  return <DetailedLounge />;
}

export default function Room() {
  return (
    <group>
      <Shell />

      {/* Rug */}
      <Box
        size={[3.45, 0.025, 2.25]}
        position={[-0.65, 0.038, -0.15]}
        color="#d6c4a5"
        radius={0.012}
      />

      <Desk />
      <Chair />
      <Shelf />
      <Lounge />

      <Plant
        position={[3.25, 0.025, -1.85]}
        scale={1.25}
      />

      <Plant
        position={[-3.35, 0.025, 1.75]}
        scale={0.9}
      />

      {/* Invisible surface receiving the room's shadow */}
      <mesh
        rotation={[-Math.PI / 2, 0, 0]}
        position={[0, -0.32, 0]}
        receiveShadow
      >
        <planeGeometry args={[200, 200]} />
        <shadowMaterial transparent opacity={0.14} />
      </mesh>
    </group>
  );
}